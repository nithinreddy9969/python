import os
os.system("pip install -r requirements.txt")
os.system("python db.py")
os.system("python main.py")