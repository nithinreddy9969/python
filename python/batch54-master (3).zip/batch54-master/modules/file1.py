a=10
b=20
c=a+b
d=a-b
def fun():
	print("this is fun in file1")
#fun()