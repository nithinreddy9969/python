print("this is init")
a=10
