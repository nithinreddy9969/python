print("this is f1")
def fun():
	print("this is fun in f1")
fun()