print("this is f2")
def fun():
	print("this is fun in f2")