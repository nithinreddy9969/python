'''
import folder1
print(folder1.f2.fun())
'''
'''
from folder1 import f2
f2.fun()
'''