a=1000
b=2000
c=a
d=1000
print(a,id(a),type(a))
print(b,id(b),type(b))
print(c,id(c),type(c))
print(d,id(d),type(d))