a=10
b=20
print(a>b)
if a>b:
    print("a is big")
else:
    print("b is big")
print("thanks you..")