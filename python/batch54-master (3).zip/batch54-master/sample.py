print("program started")
a=10
b=20
res=a+b
print("%s+%s=%s"%(a,b,res))
